#!/bin/bash
#
#bash script to test the keygen

for i in {1..10000}
do
   ./little_crackme_keygen
done